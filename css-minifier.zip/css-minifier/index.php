<?php
    if (isset($_POST['submit'])) {
    	$txt = $_POST['txt'];

    	// setup the URL and read the CSS from a file
	    $url = 'https://cssminifier.com/raw';
	    $css = $txt;

	    // init the request, set various options, and send it
	    $ch = curl_init();

	    curl_setopt_array($ch, [
	        CURLOPT_URL => $url,
	        CURLOPT_RETURNTRANSFER => true,
	        CURLOPT_POST => true,
	        CURLOPT_HTTPHEADER => ["Content-Type: application/x-www-form-urlencoded"],
	        CURLOPT_POSTFIELDS => http_build_query([ "input" => $css ])
	    ]);

	    $minified = curl_exec($ch);

	    // finally, close the request
	    curl_close($ch);
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="style.css">
	<title>CSS Minifier using PHP | Brave Coder</title>
</head>
<body>
	<div class="container shadow">
		<form class="form" action="" method="post">
			<div class="form-group">
				<textarea name="txt" rows="5" class="form-control" placeholder="Enter your CSS Code" required></textarea>
			</div>

			<div class="form-group">
				<button type="submit" name="submit" class="btn btn-primary my-3" style="margin: 0 auto; display: block; text-align: center;">Submit</button>
			</div>

			<div class="form-group">
				<textarea rows="5" class="form-control" disabled><?php if (isset($_POST['submit'])) { echo $minified; } ?></textarea>
			</div>
		</form>
	</div>
</body>
</html>